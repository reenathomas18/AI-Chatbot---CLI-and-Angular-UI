import { Component, OnInit } from '@angular/core';
import { GoogleChartsModule } from 'angular-google-charts';

@Component({
  selector: 'app-esa',
  templateUrl: './esa.component.html',
  styleUrls: []
})
export class EsaComponent implements OnInit {

  constructor() { }
  main_title='EMAIL SECURITY APPLIANCE'
  title = 'No of Incoming Messages';
  type='PieChart';
 
  data = [
    ['Clean Messages', 25.0],
    ['Suspected Messages', 26.8],
    ['Threat Messages', 12.8],
    ['Malware Messages', 8.5],
    ['Spam Messages', 6.2],
    ['Others', 0.7] 
   ];
  options = {
  colors: ['#e0440e', '#e6693e', '#ec8f6e', '#f3b49f', '#f6c7b6'], is3D: true
   };
  width = 600;
  height = 600;
  //TREE MAP
  title1 = 'Threat Messages '
  type1 = 'TreeMap';
  data1 = [
    ["Global",null,-2,33],
    ["Reputation Filtering","Global",33,0],
    ["Invalid Recipients","Global",23,11],
    ["Antispam","Global",11,2],
    ["AMP","Global",11,22],
    ["Anti Virus","Global",0,0],

    ["USA","Reputation Filtering",52,31],
    ["Mexico","Reputation Filtering",24,12],
    
    ["France","Invalid Recipients",42,-11],
    ["Germany","Invalid Recipients",31,-2],
    
    ["China","Antispam",36,4],
    ["Japan","Antispam",20,-12],
    ["India","Antispam",40,63],

    ["Egypt","Anti Virus",21,0],
    ["Congo","Anti Virus",10,12],
    ["Zaire","Anti Virus",8,10],

  
        
 ];
 options1 = { 
    minColor:"#ff7777",
    midColor:'#ffff77',
    maxColor: '#77ff77',
    headerHeight:15,
    showScale:true
 };
 width1 = 550;
 height1 = 300;

  ngOnInit(){
    (function(d, m){
        var kommunicateSettings = 
            {"appId":"243390466dfc10aa8be5cc74a30ae5bf4","popupWidget":true,"automaticChatOpenOnNavigation":true};
        var s = document.createElement("script"); s.type = "text/javascript"; s.async = true;
        s.src = "https://widget.kommunicate.io/v2/kommunicate.app";
        var h = document.getElementsByTagName("head")[0]; h.appendChild(s);
        (window as any).kommunicate = m; m._globals = kommunicateSettings;
    })(document, (window as any).kommunicate || {});
/* NOTE : Use web server to view HTML files as real-time update will not work if you directly open the HTML file in the browser. */
  }
}
