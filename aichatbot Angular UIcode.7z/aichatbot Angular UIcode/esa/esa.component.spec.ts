import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EsaComponent } from './esa.component';

describe('EsaComponent', () => {
  let component: EsaComponent;
  let fixture: ComponentFixture<EsaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EsaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EsaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
