import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { GoogleChartsModule } from 'angular-google-charts';
import { AppComponent } from './app.component';
import { EsaComponent } from './esa/esa.component';

@NgModule({
  declarations: [
    AppComponent,
    EsaComponent
  ],
  imports: [
    BrowserModule,
    GoogleChartsModule,
  ],
  providers: [],
  bootstrap: [EsaComponent]
})
export class AppModule { }
